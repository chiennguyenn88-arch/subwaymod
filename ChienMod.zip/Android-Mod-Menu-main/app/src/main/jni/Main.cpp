#include <list>
#include <vector>
#include <cstring>
#include <pthread.h>
#include <thread>
#include <string>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.hpp"
#include "Menu/Menu.hpp"
#include "Menu/Jni.hpp"
#include "Includes/Macros.h"
#include "dobby.h"

// --- 1. KHAI BÁO BIẾN TOÀN CỤC ---
bool godMode = false;
int jumpMul = 1;
int gravityDiv = 1;
int jumpLimitVal = 1;
bool addCoinsBtn = false;
bool addKeysBtn = false;

// --- 2. DANH SÁCH TÍNH NĂNG TRÊN MENU ---
jobjectArray GetFeatureList(JNIEnv *env, jobject context) {
    jobjectArray ret;

    const char *features[] = {
            OBFUSCATE("0_Toggle_God Mode (Bat tu)"),
            OBFUSCATE("1_SeekBar_Jump Height (Nhay cao)_1_10"),
            OBFUSCATE("2_SeekBar_Gravity (Trong luc)_1_10"),
            OBFUSCATE("3_SeekBar_Jump Limit (Gioi han nhay)_1_10"),
            OBFUSCATE("4_Button_Add 1000 Coins"),
            OBFUSCATE("5_Button_Add 1000 Keys")
    };

    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    return (ret);
}

#define targetLibName OBFUSCATE("libil2cpp.so")

// --- 3. XỬ LÝ SỰ KIỆN MENU (CHANGES) ---
void Changes(JNIEnv *env, jclass clazz, jobject obj, jint featNum, jstring featName, jint value, jlong Lvalue, jboolean boolean, jstring text) {
    switch (featNum) {
        case 0:
            godMode = boolean;
            break;
        case 1:
            jumpMul = value;
            break;
        case 2:
            gravityDiv = value;
            break;
        case 3:
            jumpLimitVal = value;
            break;
        case 4:
            addCoinsBtn = true;
            break;
        case 5:
            addKeysBtn = true;
            break;
        default:
            break;
    }
}

// --- 4. CÁC HÀM HOOK SUBWAY SURFERS ---
void (*old_OnCollision)(void *instance, void *collisionInfo);
void OnCollision(void *instance, void *collisionInfo) {
    if (godMode) return; // Bật God Mode thì bỏ qua va chạm
    return old_OnCollision(instance, collisionInfo);
}

float (*old_get_JumpHeight)(void *instance);
float get_JumpHeight(void *instance) {
    if (instance != NULL && jumpMul > 1) {
        return old_get_JumpHeight(instance) * jumpMul;
    }
    return old_get_JumpHeight(instance);
}

float (*old_get_Gravity)(void *instance);
float get_Gravity(void *instance) {
    if (instance != NULL && gravityDiv > 1) {
        return old_get_Gravity(instance) / gravityDiv;
    }
    return old_get_Gravity(instance);
}

int (*old_get_JumpLimit)(void *instance);
int get_JumpLimit(void *instance) {
    if (instance != NULL && jumpLimitVal > 1) {
        return jumpLimitVal;
    }
    return old_get_JumpLimit(instance);
}

void (*old_AddCoins)(void *instance, int amount);
void AddCoins(void *instance, int amount) {
    if (addCoinsBtn) {
        amount += 1000;
        addCoinsBtn = false;
    }
    return old_AddCoins(instance, amount);
}

void (*old_AddKeys)(void *instance, int amount);
void AddKeys(void *instance, int amount) {
    if (addKeysBtn) {
        amount += 1000;
        addKeysBtn = false;
    }
    return old_AddKeys(instance, amount);
}

// --- 5. LUỒNG KÍCH HOẠT HOOK (HACK THREAD) ---
void hack_thread() {
    while (!isLibraryLoaded(targetLibName)) {
        sleep(1);
    }

#if defined(__aarch64__)
    HOOK(targetLibName, "0x1ff11d8", OnCollision, old_OnCollision);
    HOOK(targetLibName, "0x1f0e738", get_JumpHeight, old_get_JumpHeight);
    HOOK(targetLibName, "0x1f0e140", get_Gravity, old_get_Gravity);
    HOOK(targetLibName, "0x1f095a0", get_JumpLimit, old_get_JumpLimit);
    HOOK(targetLibName, "0x1f7b390", AddCoins, old_AddCoins);
    HOOK(targetLibName, "0x1f7b3bc", AddKeys, old_AddKeys);
#elif defined(__arm__)
    // Dành cho thiết bị armv7 (nếu cần)
#endif

    LOGI(OBFUSCATE("Subway Surfers Mod Menu Loaded Successfully!"));
}

__attribute__((constructor))
void lib_main() {
    std::thread(hack_thread).detach();
}
